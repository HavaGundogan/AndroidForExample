package com.gundogan.parselearning;

import android.app.Application;
import  com.
public class ParseLearn extends Application
{
    @Override
    public void onCreate() {
        super.onCreate();



    }
}